Program xdemot;
uses Crt,Graph;
const
  ZXname : string = 'fromIBM C'#0#64#0#27#0#27#206#104;
var
 TF,ZF:File of Char;
 name,name1,name2:string;
 b:array [0..191,0..31] of byte;
 c,cc:char;
 n:Longint;
 gr,modd,i,j,k,m,ix,ixx:integer;
label
     Laba;

begin
  ClrScr;
  n:=0;
  Writeln('��������� TIFF-䠩���');
  Writeln('(Black & White  128�128)');
  Writeln('� ����-⥪��-䠩��'#10#10);
  gr:=CGA;
  InitGraph(gr,modd,'d:\tp7\bgi\');
  name2:='d:\'#39'ufo2'#39'\data\xdemotxt'+Name+'.dat';
  Assign(ZF,name2);
  rewrite(ZF);
  for ixx:=1 to 28 do begin
  str(ixx+ix*8,Name);
  name1:='d:\'#39'ufo2'#39'\xdemo\Xt'+Name+'.tif';
  Assign(TF,name1);
  Reset(TF);

  for i:=1 to 194 do read(TF,c);         {read TIFF prefix}
  cc:=#0;
  for i:=0 to 23 do
    for j:=0 to 23 do                     {read & display TIFF screen}
       begin
         read (TF,c);
         for m:=0 to 7 do putpixel(j*8+m,i,(ord(c) shr (7-m) and 1)*7);
         c:=chr(not ord(c));
         if (cc='�') and (c='�') then
                   begin
                     dec (c);
                     writeln(#7+'Warning: #ED #ED');
                   end;
         cc:=c;
         write (ZF,c);
       end;

  Close(TF);
  end;

  Close(ZF);
{  goto Laba;}
  repeat until KeyPressed;
  CloseGraph;

end.